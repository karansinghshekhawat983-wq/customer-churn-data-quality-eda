# Customer Churn: Data Quality and Exploratory Analysis

EdVyro Data Analytics Task 1. Audit and clean a customer churn dataset, document the quality decisions, and identify initial churn patterns.

**Start here:** open `Customer_Churn_Data_Quality_and_EDA.ipynb` (all outputs and charts are already saved in it, so it can be read directly on GitHub).

## Repository contents

| File | Purpose |
|---|---|
| `Customer_Churn_Data_Quality_and_EDA.ipynb` | Full analysis: profiling, audit, cleaning, validation, statistics, EDA, conclusion |
| `customer_churn_sample.csv` | Original dataset supplied by EdVyro (unmodified) |
| `outputs/customer_churn_clean.csv` | Cleaned dataset (original 11 columns plus 4 derived columns) |
| `outputs/data_dictionary.csv` | Data dictionary for every column |
| `outputs/cleaning_log.csv` | What each cleaning step did and how many rows it changed |
| `outputs/validation_results.csv` | Results of the 20 automated validation checks |
| `outputs/figures/` | The 8 charts as PNG files |

## Summary of results

* **Data quality:** 15 rows x 11 columns. No missing values, duplicates, outliers or rule violations were found (16 audit rules, 20 validation checks, all passing). No original values were changed.
* **Churn:** 7 of 15 customers (46.7%) churned.
* **Main patterns:** all Month-to-Month customers churned (7/7) and none on annual contracts (0/8); all churn occurred at 14 months of tenure or less; every customer with 3 or more support tickets churned. Subscription tier looks predictive but is explained by contract type.
* **Caveat:** the dataset is small (n = 15) and synthetic, so results illustrate the method and should not be generalized.

## How to run

```bash
pip install -r requirements.txt
jupyter notebook Customer_Churn_Data_Quality_and_EDA.ipynb
```

Keep `customer_churn_sample.csv` in the same folder as the notebook. Running all cells regenerates everything in `outputs/`.
